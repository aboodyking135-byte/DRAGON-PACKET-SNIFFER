package com.dragon.sniffer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.ActivityNotFoundException;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private static final int PORT = 5123;
    private static final String PCAP_PKG = "com.emanuelef.remote_capture";
    private static final String PCAP_ACTIVITY = "com.emanuelef.remote_capture.activities.CaptureCtrl";
    private static final String FF_MAX = "com.dts.freefiremax";
    private static final String FF_NORMAL = "com.dts.freefireth";
    private boolean useMax = true;
    private boolean capturing = false;
    private DatagramSocket socket;
    private Thread receiver;
    private final AtomicBoolean keepReceiving = new AtomicBoolean(false);
    private TextView status, counters, output;
    private int packetCount = 0;
    private long byteCount = 0;
    private final StringBuilder lines = new StringBuilder();

    private final ActivityResultLauncher<Intent> captureLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), this::onCaptureResult);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        if (!isPcapInstalled()) setStatus("Install PCAPdroid first");
    }

    private boolean isPcapInstalled() {
        try { getPackageManager().getPackageInfo(PCAP_PKG, 0); return true; }
        catch (Exception e) { return false; }
    }

    private TextView label(String text, int size, int color) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(12, 8, 12, 8); return t;
    }
    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); return b;
    }
    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(14, 14, 14, 10); root.setBackgroundColor(Color.rgb(9,13,24));
        TextView title = label("DRAGON  /  PACKET SNIFFER", 22, Color.rgb(0,212,255));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); root.addView(title);
        root.addView(label("Live TCP / UDP monitor  •  No Root", 13, Color.LTGRAY));
        status = label("● STOPPED", 14, 0xFFFFB74D); root.addView(status);
        counters = label("Packets: 0     Data: 0 B", 13, Color.WHITE); root.addView(counters);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button appBtn = button("Target: FREE FIRE MAX");
        appBtn.setOnClickListener(v -> { useMax = !useMax; appBtn.setText(useMax ? "Target: FREE FIRE MAX" : "Target: FREE FIRE"); });
        row.addView(appBtn, new LinearLayout.LayoutParams(0, -2, 1));
        Button start = button("START"); row.addView(start, new LinearLayout.LayoutParams(0, -2, 1));
        Button stop = button("STOP"); row.addView(stop, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);
        start.setOnClickListener(v -> startCapture()); stop.setOnClickListener(v -> stopCapture());
        Button clear = button("CLEAR LOG"); clear.setOnClickListener(v -> { lines.setLength(0); output.setText(""); }); root.addView(clear);
        ScrollView scroll = new ScrollView(this); output = label("Waiting for packets...", 12, 0xFFB9D7E8);
        output.setTypeface(Typeface.MONOSPACE); scroll.addView(output);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView note = label("Capture is provided by PCAPdroid via its local UDP exporter. Payload preview may contain encrypted data.", 11, 0xFF9AA7B5);
        root.addView(note); setContentView(root);
    }

    private void setStatus(String s) { if (status != null) status.setText(s); }
    private void startCapture() {
        if (capturing) return;
        if (!isPcapInstalled()) { Toast.makeText(this, "Please install PCAPdroid", Toast.LENGTH_LONG).show(); return; }
        startReceiver();
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setClassName(PCAP_PKG, PCAP_ACTIVITY);
        i.putExtra("action", "start");
        i.putExtra("pcap_dump_mode", "udp_exporter");
        i.putExtra("collector_host", "127.0.0.1");
        i.putExtra("collector_port", String.valueOf(PORT));
        i.putExtra("app_filter", useMax ? FF_MAX : FF_NORMAL);
        i.putExtra("pcapdroid_trailer", true);
        try { captureLauncher.launch(i); }
        catch (ActivityNotFoundException e) { stopReceiver(); Toast.makeText(this, "PCAPdroid activity not found. Update PCAPdroid.", Toast.LENGTH_LONG).show(); }
    }
    private void onCaptureResult(ActivityResult result) {
        if (result.getResultCode() == Activity.RESULT_OK) {
            capturing = true; setStatus("● CAPTURING  /  " + (useMax ? "FREE FIRE MAX" : "FREE FIRE"));
            addLine("Capture started. Open the selected game now.");
        } else {
            stopReceiver(); setStatus("● START DENIED / CANCELLED");
            addLine("PCAPdroid did not start capture. Approve its permission prompt.");
        }
    }
    private void stopCapture() {
        if (isPcapInstalled()) {
            Intent i = new Intent(Intent.ACTION_VIEW); i.setClassName(PCAP_PKG, PCAP_ACTIVITY); i.putExtra("action", "stop");
            try { captureLauncher.launch(i); } catch (Exception ignored) { }
        }
        capturing = false; stopReceiver(); setStatus("● STOPPED");
    }
    private void startReceiver() {
        stopReceiver(); keepReceiving.set(true);
        receiver = new Thread(() -> {
            try {
                socket = new DatagramSocket(PORT, InetAddress.getByName("127.0.0.1"));
                byte[] buf = new byte[65535];
                while (keepReceiving.get()) {
                    DatagramPacket d = new DatagramPacket(buf, buf.length); socket.receive(d);
                    int len = d.getLength(); byte[] data = new byte[len]; System.arraycopy(d.getData(), d.getOffset(), data, 0, len);
                    PacketInfo info = parsePcapDatagram(data);
                    if (info != null) runOnUiThread(() -> showPacket(info, len));
                }
            } catch (SocketException e) { /* closed intentionally */ }
            catch (Exception e) { runOnUiThread(() -> addLine("Receiver error: " + e.getMessage())); }
        }, "dragon-pcap-udp");
        receiver.start();
    }
    private void stopReceiver() {
        keepReceiving.set(false); if (socket != null) { socket.close(); socket = null; }
        receiver = null;
    }
    private static class PacketInfo { String proto, src, dst, hex; int payloadLen; }
    private PacketInfo parsePcapDatagram(byte[] b) {
        // PCAPdroid UDP exporter sends a PCAP record header followed by an Ethernet frame.
        if (b.length < 16 + 14 + 20) return null;
        int off = 16;
        int ether = u16(b, off + 12);
        if (ether != 0x0800) return null; // IPv4 view
        int ip = off + 14; int verIhl = b[ip] & 255; if ((verIhl >>> 4) != 4) return null;
        int ihl = (verIhl & 15) * 4; if (ihl < 20 || b.length < ip + ihl) return null;
        int total = u16(b, ip + 2); int proto = b[ip + 9] & 255;
        int l4 = ip + ihl; PacketInfo p = new PacketInfo();
        if (proto == 6) p.proto = "TCP"; else if (proto == 17) p.proto = "UDP"; else return null;
        if (b.length < l4 + (proto == 6 ? 20 : 8)) return null;
        p.src = ipv4(b, ip + 12) + ":" + u16(b, l4);
        p.dst = ipv4(b, ip + 16) + ":" + u16(b, l4 + 2);
        int hdr = proto == 6 ? ((b[l4 + 12] >>> 4) & 15) * 4 : 8;
        int payload = Math.min(b.length, ip + Math.max(ihl + hdr, Math.min(total, b.length - ip)));
        int payloadStart = Math.min(b.length, l4 + hdr);
        p.payloadLen = Math.max(0, payload - payloadStart);
        p.hex = hex(b, payloadStart, Math.min(p.payloadLen, 48));
        return p;
    }
    private int u16(byte[] b, int o) { return ((b[o] & 255) << 8) | (b[o+1] & 255); }
    private String ipv4(byte[] b, int o) { return (b[o]&255)+"."+(b[o+1]&255)+"."+(b[o+2]&255)+"."+(b[o+3]&255); }
    private String hex(byte[] b, int o, int n) { StringBuilder s=new StringBuilder(); for(int x=0;x<n;x++) s.append(String.format(Locale.US,"%02X",b[o+x]&255)); return s.toString(); }
    private void showPacket(PacketInfo p, int datagramBytes) {
        packetCount++; byteCount += datagramBytes;
        counters.setText("Packets: " + packetCount + "     Data: " + byteCount + " B");
        addLine(p.proto + "  " + p.src + "  ->  " + p.dst + "  | payload=" + p.payloadLen + " B\nHEX: " + (p.hex.isEmpty() ? "[no payload]" : p.hex));
    }
    private void addLine(String s) {
        lines.insert(0, s + "\n\n"); if (lines.length() > 45000) lines.setLength(45000);
        output.setText(lines.toString());
    }
    @Override protected void onDestroy() { stopReceiver(); super.onDestroy(); }
}
