# DRAGON Packet Sniffer (Android)

A lightweight Android companion app for viewing live IPv4 TCP/UDP packets from one selected app, without root. It uses the official PCAPdroid app API and its local UDP exporter.

## Important requirements
- PCAPdroid must also be installed: https://f-droid.org/packages/com.emanuelef.remote_capture/
- The first capture requires approving PCAPdroid's capture/consent prompt.
- Select Free Fire MAX (`com.dts.freefiremax`) or Free Fire (`com.dts.freefireth`) in the app.
- This app does not extract game AES/session keys, decrypt game traffic, or bypass game protections. Encrypted payloads remain encrypted.
- Android VPN capture is performed by PCAPdroid. This companion receives the local PCAP stream; it is not a standalone VPN capture engine.

## Build APK
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then choose **Build > Build APK(s)**. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions build
Push the project to a GitHub repository. The workflow `.github/workflows/android.yml` builds a debug APK on each push and uploads it as an artifact named `dragon-debug-apk`.

## Notes
- The app listens on `127.0.0.1:5123` and asks PCAPdroid to export packets to that local UDP port.
- Packet preview is limited to the first 48 payload bytes to keep the UI responsive.
- IPv4 TCP/UDP is shown. IPv6 and non-IP Ethernet frames are currently skipped.
